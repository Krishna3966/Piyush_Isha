let count: number = 10
count = "Hello"

//Static checking


/*
Code Runner Extension by Jun Han 
Live Server Extension by Ritwick Dey. 
Material Icon Theme by Philipp Kief 
Open in default browser by peakchen90. 
Playwright Test for VS Code
*/
